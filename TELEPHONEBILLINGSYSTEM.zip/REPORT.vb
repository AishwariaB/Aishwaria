﻿Public Class REPORT

    Private Sub REPORT_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TELEPHONEBILLINGDataSet1.PAYMENTDETAILS' table. You can move, or remove it, as needed.
        Me.PAYMENTDETAILSTableAdapter.Fill(Me.TELEPHONEBILLINGDataSet1.PAYMENTDETAILS)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class