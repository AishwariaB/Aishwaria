﻿Imports System.Data.Sql
Imports System.Data.SqlClient


Public Class LOGIN

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    'LOAD'

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load




        con.ConnectionString = "Data Source=desktop-nb555dn\sqlexpress;Initial Catalog=TELEPHONEBILLING;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        TextBox1.Text = ""

        TextBox2.Text = ""

    End Sub



    'NEW MEMBER'
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        NEWCUSTOMER.Show()
        Me.Hide()
    End Sub

    'LOGIN'

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim TEST As Integer


        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT count(TELEPHONENUMBER) FROM MEMBERDETAILS WHERE TELEPHONENUMBER = '" + TextBox1.Text + "' AND PASSWORD = '" + TextBox2.Text + "'"
        cmd.ExecuteNonQuery()

        TEST = CType(cmd.ExecuteScalar(), Integer)

        If TEST = 1 Then
            Dim OBJ1 As New MEMBERDETAILS
            OBJ1.TPASS = TextBox1.Text

            OBJ1.PPASS = TextBox2.Text

            MDIParent1.Show()
            OBJ1.Show()


            Me.Hide()

        Else
            MessageBox.Show("NO SUCH CUSTOMER")
        End If

    End Sub
End Class