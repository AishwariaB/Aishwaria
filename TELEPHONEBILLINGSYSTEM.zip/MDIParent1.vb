﻿Imports System.Windows.Forms

Public Class MDIParent1





    'MEMBERDETAILS'
    Private Sub MEMEBERDETAILSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MEMEBERDETAILSToolStripMenuItem.Click
        Dim F As New MEMBERDETAILS
        F.MdiParent = Me
        F.Show()
        PictureBox1.Hide()
        Label1.Hide()



    End Sub



    'LOGOUT'
    Private Sub LOGOUTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LOGOUTToolStripMenuItem.Click
        MessageBox.Show("ARE YOU SURE YOU WANT TO LOG OUT", "CANCEL", MessageBoxButtons.OK)
        Me.Hide()




    End Sub

    Private Sub REPORTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles REPORTToolStripMenuItem.Click
        REPORT.Show()


    End Sub

    Private Sub MDIParent1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
