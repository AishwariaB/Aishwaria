﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class NEWCUSTOMER
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand


    Private Sub NEWCUSTOMER_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con.ConnectionString = "Data Source=desktop-nb555dn\sqlexpress;Initial Catalog=TELEPHONEBILLING;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
    End Sub
    

    'SAVE'
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "INSERT INTO MEMBERDETAILS VALUES('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')"
        cmd.ExecuteNonQuery()
        MessageBox.Show("CUSTOMER NEWLY ADDED!", "SAVED", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Me.Hide()
        Dim F As New LOGIN
        F.Show()
    End Sub
End Class