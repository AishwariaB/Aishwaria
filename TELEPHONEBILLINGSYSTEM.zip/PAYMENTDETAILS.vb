﻿Imports System.Data.Sql
Imports System.Data.SqlClient


Public Class PAYMENTDETAILS

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Public Property PASS As String


    Private Sub PAYMENTDETAILS_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TELEPHONEBILLINGDataSet.PAYMENTDETAILS' table. You can move, or remove it, as needed.
        Me.PAYMENTDETAILSTableAdapter.Fill(Me.TELEPHONEBILLINGDataSet.PAYMENTDETAILS)
        con.ConnectionString = "Data Source=desktop-nb555dn\sqlexpress;Initial Catalog=TELEPHONEBILLING;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()

        TextBox1.Text = PASS
    End Sub


    

    ' DISPLAY DATA'
    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select*from PAYMENTDETAILS WHERE TELEPHONENUMBER ='" + TextBox1.Text + "' "
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    


   

    'CANCEL' 
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Hide()

    End Sub

    'TELEPHONE NUMBER TEXT CHANGE'
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select TOTALCALLS FROM PAYMENTDETAILS where TELEPHONENUMBER ='" + TextBox1.Text + "'"
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        DataGridView1.DataSource = dt

        Dim TOTALCALLS As New Integer
        TOTALCALLS = CType(cmd.ExecuteScalar(), Integer)



        If dt.Rows.Count() > 0 Then

            TextBox3.Text = dt.Rows(0)(0).ToString()

        Else

            TextBox3.Text = ""
        End If
        TextBox7.Text = "Rs 100"
        TextBox2.Text = "Rs 5"
        TextBox5.Text = " 2%"

        'TOTAL BILL CALCULATION'

        Dim FIXEDCHARGES As Integer = 100
        Dim PERCALLCHARGES As Integer = 5
        Dim GST As Integer = 2
        Dim TOTALBILL As Decimal = 0
        TOTALBILL = FIXEDCHARGES + (PERCALLCHARGES * TOTALCALLS)
        TOTALBILL = TOTALBILL + ((TOTALBILL * GST) / 100)


        'MsgBox(TOTALBILL)
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE PAYMENTDETAILS SET BILLAMOUNT = '" & TOTALBILL & "'WHERE TELEPHONENUMBER = '" + TextBox1.Text + "'"
        cmd.ExecuteNonQuery()
        TextBox6.Text = TOTALBILL
        Dim dt1 As New DataTable()
        Dim da1 As New SqlDataAdapter(cmd)
        da1.SelectCommand = cmd
        da1.Fill(dt1)
        disp_data()

    End Sub

End Class