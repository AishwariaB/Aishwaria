﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MEMBERDETAILS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.MEMBERDETAILSBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.PAYMENTDETAILSBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.MEMBERDETAILSBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.MEMBERDETAILSBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PAYMENTDETAILSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PAYMENTDETAILSBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.MEMBERDETAILSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TELEPHONEBILLINGDataSet = New $safeprojectname$.TELEPHONEBILLINGDataSet()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.MEMBERDETAILSTableAdapter = New $safeprojectname$.TELEPHONEBILLINGDataSetTableAdapters.MEMBERDETAILSTableAdapter()
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CUSTOMERNAMEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CITYDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.MEMBERDETAILSBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PAYMENTDETAILSBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MEMBERDETAILSBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MEMBERDETAILSBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PAYMENTDETAILSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PAYMENTDETAILSBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MEMBERDETAILSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TELEPHONEBILLINGDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(195, 145)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(110, 20)
        Me.TextBox4.TabIndex = 13
        '
        'MEMBERDETAILSBindingSource1
        '
        Me.MEMBERDETAILSBindingSource1.DataMember = "MEMBERDETAILS"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 87)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 27)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "NAME"
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(422, 234)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(410, 39)
        Me.Button4.TabIndex = 47
        Me.Button4.Text = "CHECK PAYMENT"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'MEMBERDETAILSBindingSource2
        '
        Me.MEMBERDETAILSBindingSource2.DataMember = "MEMBERDETAILS"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 145)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 27)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "CITY"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(173, 171)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 13)
        Me.Label3.TabIndex = 37
        '
        'PAYMENTDETAILSBindingSource
        '
        Me.PAYMENTDETAILSBindingSource.DataMember = "PAYMENTDETAILS"
        '
        'PAYMENTDETAILSBindingSource1
        '
        Me.PAYMENTDETAILSBindingSource1.DataMember = "PAYMENT DETAILS"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(195, 86)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(110, 20)
        Me.TextBox3.TabIndex = 11
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(243, 48)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(110, 20)
        Me.TextBox5.TabIndex = 27
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.DarkCyan
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.TELEPHONENUMBERDataGridViewTextBoxColumn, Me.CUSTOMERNAMEDataGridViewTextBoxColumn, Me.CITYDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.MEMBERDETAILSBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(141, 291)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(634, 150)
        Me.DataGridView1.TabIndex = 46
        '
        'MEMBERDETAILSBindingSource
        '
        Me.MEMBERDETAILSBindingSource.DataMember = "MEMBERDETAILS"
        Me.MEMBERDETAILSBindingSource.DataSource = Me.TELEPHONEBILLINGDataSet
        '
        'TELEPHONEBILLINGDataSet
        '
        Me.TELEPHONEBILLINGDataSet.DataSetName = "TELEPHONEBILLINGDataSet"
        Me.TELEPHONEBILLINGDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CalendarForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.DateTimePicker1.Location = New System.Drawing.Point(684, 1)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 43
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(388, 57)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(0, 13)
        Me.Label10.TabIndex = 42
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(391, 109)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 13)
        Me.Label8.TabIndex = 41
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(236, 234)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(164, 39)
        Me.Button2.TabIndex = 40
        Me.Button2.Text = "DELETE"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(6, 145)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 27)
        Me.Label11.TabIndex = 32
        Me.Label11.Text = "GST"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(195, 34)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(110, 20)
        Me.TextBox1.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(71, 234)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(150, 39)
        Me.Button1.TabIndex = 39
        Me.Button1.Text = "UPDATE"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 41)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(194, 27)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "FIXED CHARGES"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(179, 180)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(0, 13)
        Me.Label4.TabIndex = 38
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(243, 145)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(110, 20)
        Me.TextBox6.TabIndex = 28
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(193, 27)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "TELEPHONE NO."
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightSkyBlue
        Me.GroupBox1.Controls.Add(Me.TextBox5)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.TextBox6)
        Me.GroupBox1.Controls.Add(Me.TextBox7)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Location = New System.Drawing.Point(422, 23)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(410, 205)
        Me.GroupBox1.TabIndex = 44
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "CHARGES"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(243, 94)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.ReadOnly = True
        Me.TextBox7.Size = New System.Drawing.Size(110, 20)
        Me.TextBox7.TabIndex = 29
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(6, 93)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(231, 27)
        Me.Label9.TabIndex = 31
        Me.Label9.Text = "PER CALL CHARGES"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.LightSkyBlue
        Me.GroupBox2.Controls.Add(Me.TextBox4)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.TextBox3)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.TextBox1)
        Me.GroupBox2.Location = New System.Drawing.Point(71, 23)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(329, 205)
        Me.GroupBox2.TabIndex = 45
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "INFO"
        '
        'MEMBERDETAILSTableAdapter
        '
        Me.MEMBERDETAILSTableAdapter.ClearBeforeFill = True
        '
        'TELEPHONENUMBERDataGridViewTextBoxColumn
        '
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn.DataPropertyName = "TELEPHONENUMBER"
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn.HeaderText = "TELEPHONENUMBER"
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn.Name = "TELEPHONENUMBERDataGridViewTextBoxColumn"
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn.Width = 200
        '
        'CUSTOMERNAMEDataGridViewTextBoxColumn
        '
        Me.CUSTOMERNAMEDataGridViewTextBoxColumn.DataPropertyName = "CUSTOMERNAME"
        Me.CUSTOMERNAMEDataGridViewTextBoxColumn.HeaderText = "CUSTOMERNAME"
        Me.CUSTOMERNAMEDataGridViewTextBoxColumn.Name = "CUSTOMERNAMEDataGridViewTextBoxColumn"
        Me.CUSTOMERNAMEDataGridViewTextBoxColumn.Width = 200
        '
        'CITYDataGridViewTextBoxColumn
        '
        Me.CITYDataGridViewTextBoxColumn.DataPropertyName = "CITY"
        Me.CITYDataGridViewTextBoxColumn.HeaderText = "CITY"
        Me.CITYDataGridViewTextBoxColumn.Name = "CITYDataGridViewTextBoxColumn"
        Me.CITYDataGridViewTextBoxColumn.Width = 190
        '
        'MEMBERDETAILS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(883, 473)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Name = "MEMBERDETAILS"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MEMBER DETAILS"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.MEMBERDETAILSBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PAYMENTDETAILSBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MEMBERDETAILSBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MEMBERDETAILSBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PAYMENTDETAILSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PAYMENTDETAILSBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MEMBERDETAILSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TELEPHONEBILLINGDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents MEMBERDETAILSBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents PAYMENTDETAILSBindingSource2 As System.Windows.Forms.BindingSource
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents MEMBERDETAILSBindingSource2 As System.Windows.Forms.BindingSource
    Friend WithEvents MEMBERDETAILSBindingSource3 As System.Windows.Forms.BindingSource
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PAYMENTDETAILSBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PAYMENTDETAILSBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TELEPHONEBILLINGDataSet As $safeprojectname$.TELEPHONEBILLINGDataSet
    Friend WithEvents MEMBERDETAILSBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MEMBERDETAILSTableAdapter As $safeprojectname$.TELEPHONEBILLINGDataSetTableAdapters.MEMBERDETAILSTableAdapter
    Friend WithEvents TELEPHONENUMBERDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CUSTOMERNAMEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CITYDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
