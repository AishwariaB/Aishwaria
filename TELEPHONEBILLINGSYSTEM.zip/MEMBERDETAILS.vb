﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class MEMBERDETAILS
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand


    Public Property TPASS As String
    Public Property PPASS As String


    Private Sub MEMBERDETAILS_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TELEPHONEBILLINGDataSet.MEMBERDETAILS' table. You can move, or remove it, as needed.
        Me.MEMBERDETAILSTableAdapter.Fill(Me.TELEPHONEBILLINGDataSet.MEMBERDETAILS)
        con.ConnectionString = "Data Source=desktop-nb555dn\sqlexpress;Initial Catalog=TELEPHONEBILLING;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        TextBox1.Text = TPASS
    End Sub

    


    

    'DISPLAY DATA'
    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select*from MEMBERDETAILS WHERE TELEPHONENUMBER ='" + TextBox1.Text + "' "
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub


   



    'UPDATE'
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE MEMBERDETAILS SET TELEPHONENUMBER='" + TextBox1.Text + "', PASSWORD='" + PPASS + "',CUSTOMERNAME='" + TextBox3.Text + "',CITY='" + TextBox4.Text + "' WHERE TELEPHONENUMBER ='" + TextBox1.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
        disp_data()
    End Sub


    'DELETE'
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "delete from MEMBERDETAILS where TELEPHONENUMBER  =" + TextBox1.Text + ""
        cmd.ExecuteNonQuery()
        MessageBox.Show("MEMBER RECORD HAS BEEN DELETED")
        disp_data()
    End Sub


    'CHECK PAYMENT'
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim OBJ As New PAYMENTDETAILS
        OBJ.PASS = TextBox1.Text
        OBJ.Show()
        Me.Hide()
    End Sub

    Private Sub TextBox1_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select TELEPHONENUMBER,CUSTOMERNAME,CITY FROM MEMBERDETAILS where TELEPHONENUMBER  ='" + TextBox1.Text + "'"
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        DataGridView1.DataSource = dt
        If dt.Rows.Count() > 0 Then



            TextBox3.Text = dt.Rows(0)(1).ToString()
            TextBox4.Text = dt.Rows(0)(2).ToString()


        ElseIf TextBox1.Text <> Nothing Then


            TextBox3.Text = ""
            TextBox4.Text = ""


        End If

        TextBox5.Text = "Rs 100"
        TextBox7.Text = "Rs 5"
        TextBox6.Text = " 2%"
    End Sub
End Class
